$(document).ready(function() {
    getBoardSize();
    createBoard();
});

function getBoardSize() {
    console.log("Getting board size...");
}

let cellId = 1;
let mineCells = [];
let labeledCount = 0;
function createBoard() {
    
    console.log("Creating board...");

    // create plain board
    for (let i = 1; i < 10; i++) {
        for (let j = 1; j < 10; j++) {
            let cell = $("<div>").addClass("cell").attr("id", cellId).attr("row", i).attr("col", j).attr("value", 0);
            // cell.html(cell.attr("value"));
            // cell.html(cellId);
            // cell.html(i + ", " + j);

            $("#board").append(cell);
            cellId++;
        }
    }

    // add mines
    // 10 mines for 9x9 board
    // 40 mines for 16x16 board
    // 99 mines for 16x30 board
    addMines();

    labelAroundMines();

    // add click event
    $(".cell").click(function() {
        let row = parseInt($(this).attr("row"));
        let col = parseInt($(this).attr("col"));
        console.log("Clicked on: " + row + ", " + col);
        if ($(this).hasClass("flagged")) {
            return;
        } else {
            reveal(row, col);
        }

        checkWin();
    });

    $(".cell").contextmenu(function(e) {
        let row = parseInt($(this).attr("row"));
        let col = parseInt($(this).attr("col"));
        console.log("Flagged: " + row + ", " + col);
        let flagImage = $("<img>").attr("src", "flag.png").attr("width", "20px").attr("height", "20px");
        if ($(this).hasClass("flagged")) {
            $(this).html("");
            $(this).removeClass("flagged");
            labeledCount--;
        } else {
            $(this).html(flagImage);
            $(this).addClass("flagged");
            labeledCount++;
        }

        checkWin();
        e.preventDefault();
    });

    for (let i = 1; i < 82; i++) {
        let cell = $("#" + i);
        if (cell.hasClass("revealed")){
            cell.html(cell.attr("value"))
        }
    
    }
    
    
}

function addMines() {
    console.log("Adding mines...");
    while (mineCells.length < 10) {
        let randomCell = Math.floor(Math.random() * 81) + 1;
        if (!mineCells.includes(randomCell)) {
            mineCells.push(randomCell);
            $("#" + randomCell).addClass("mine").attr("value", 9);
        }
    }
}

function labelAroundMines() {
    for (let m in mineCells) {
        mine = $("#" + mineCells[m]);
        let row = parseInt(mine.attr("row"));
        let col = parseInt(mine.attr("col"));
        // console.log("Mine at: " + row + ", " + col);

        // top left, top, top right, left, right, bottom left, bottom, bottom right
        neighborCells = [[row - 1, col - 1], [row - 1, col], [row - 1, col + 1], [row, col - 1], [row, col + 1], [row + 1, col - 1], [row + 1, col], [row + 1, col + 1]];

        for (let n in neighborCells) {
            neighbor = neighborCells[n];
            neighborCell = $('.cell[row="' + neighbor[0] + '"][col="' + neighbor[1] + '"]');
            if (!neighborCell.hasClass("mine")) {
                neighborCell.attr("value", parseInt(neighborCell.attr("value")) + 1);
            }
        }

        
    }
}

function reveal(row, col) {
    let cell = $('.cell[row="' + row + '"][col="' + col + '"]');
    if (row < 1 || row > 9 || col < 1 || col > 9 || cell.hasClass("revealed")) {
        console.log("Invalid cell")
        return;
    }

    cell.addClass("revealed");
    labeledCount++;
    console.log("Revealed: " + row + ", " + col);
    if (cell.hasClass("mine")) {
        alert("Game over!");
        return;
    } else if (cell.attr("value") == 0) {
        for (let dx = -1; dx <= 1; dx++) {
            for (let dy = -1; dy <= 1; dy++) {
                reveal(row + dx, col + dy);
            }
        }
    }

    for (let i = 1; i < 82; i++) {
        let cell = $("#" + i);
        // cell.html(cell.attr("value"));
        if (cell.hasClass("revealed")){
            if (cell.attr("value") == 0){
                cell.html("")
            } else {
                cell.html(cell.attr("value"))
            }
        }
    
    }
}


function checkWin() {
    if (labeledCount == 81) {
        alert("You win!");
    }
}